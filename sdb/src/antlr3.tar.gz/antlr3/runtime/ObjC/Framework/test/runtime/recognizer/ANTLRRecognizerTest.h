//
//  ANTLRRecognizerTest.h
//  ANTLR
//
//  Created by Ian Michell on 02/07/2010.
//  Copyright 2010 Ian Michell. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface ANTLRRecognizerTest : SenTestCase {

}

@end
