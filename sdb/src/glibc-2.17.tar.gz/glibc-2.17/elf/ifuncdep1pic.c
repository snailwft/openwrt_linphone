/* Test STT_GNU_IFUNC symbols with -fPIC.  */

#include "ifuncmod1.c"
