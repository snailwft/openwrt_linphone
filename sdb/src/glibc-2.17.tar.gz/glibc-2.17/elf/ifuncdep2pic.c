/* Test STT_GNU_IFUNC symbols with -fPIC.  */

#include "ifuncdep2.c"
